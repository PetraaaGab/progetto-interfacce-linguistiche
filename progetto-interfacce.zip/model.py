"""model.py — logica del modello per il generatore di poesie.

Usa esclusivamente: stringhe, liste, tuple, dizionari, funzioni.
Nessuna classe, nessun ORM, nessuna struttura esterna.

Flusso principale:
  1. load_dataset()      → scarica le poesie dal dataset HuggingFace (JSON lines)
  2. filter_by_theme()   → filtra per tema/tag
  3. sample_poems()      → seleziona un campione casuale come few-shot examples
  4. build_prompt()      → costruisce il prompt testuale per l'LLM
  5. call_llm()          → chiama l'API Anthropic e restituisce la poesia
"""

import random
import json
import urllib.request


# ---------------------------------------------------------------------------
# Struttura dati del dataset
# ---------------------------------------------------------------------------
# Ogni poesia è un dizionario con le chiavi:
#   "title"  (str)  — titolo della poesia
#   "poem"   (str)  — testo completo della poesia
#   "author" (str)  — autore
#   "tags"   (str)  — tag separati da virgola (es. "love, nature, death")
#
# Il dataset globale è una lista di questi dizionari.
# Usiamo una variabile di modulo come "stato" (come nell'esempio della prof).

_dataset: list = []   # lista di dict {"title", "poem", "author", "tags"}
_is_loaded: bool = False


# ---------------------------------------------------------------------------
# 1. Caricamento dataset
# ---------------------------------------------------------------------------

def load_dataset(url: str = "https://huggingface.co/datasets/suayptalha/Poetry-Foundation-Poems/resolve/main/data/train-00000-of-00001.parquet") -> dict:
    """Scarica e carica il dataset di poesie in memoria.

    Il dataset HuggingFace è in formato Parquet; lo convertiamo usando
    l'endpoint di HuggingFace che espone i dati come JSON tramite la
    Datasets Viewer API (rows endpoint), che non richiede autenticazione.

    Returns:
        dict con chiavi: ok (bool), count (int), error (str|None)
    """
    global _dataset, _is_loaded

    # HuggingFace Datasets Viewer API — restituisce JSON con "rows"
    api_url = (
        "https://datasets-server.huggingface.co/rows"
        "?dataset=suayptalha%2FPoetry-Foundation-Poems"
        "&config=default&split=train&offset=0&length=100"
    )

    try:
        req = urllib.request.Request(api_url, headers={"User-Agent": "poetry-gen/1.0"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            raw = resp.read().decode("utf-8")
        data = json.loads(raw)
    except Exception as e:
        return {"ok": False, "count": 0, "error": str(e)}

    # La risposta ha struttura: {"rows": [{"row": {...}}, ...]}
    rows = data.get("rows", [])
    parsed: list = []
    for entry in rows:
        row = entry.get("row", {})
        # normalizza le chiavi (il dataset usa nomi variabili)
        poem_dict = {
            "title":  str(row.get("Title",  row.get("title",  ""))),
            "poem":   str(row.get("Poem",   row.get("poem",   ""))),
            "author": str(row.get("Poet",   row.get("author", ""))),
            "tags":   str(row.get("Tags",   row.get("tags",   ""))),
        }
        # scarta righe vuote
        if poem_dict["poem"].strip():
            parsed.append(poem_dict)

    _dataset = parsed
    _is_loaded = True
    return {"ok": True, "count": len(_dataset), "error": None}


def is_loaded() -> bool:
    """Restituisce True se il dataset è stato caricato."""
    return _is_loaded and len(_dataset) > 0


def dataset_info() -> dict:
    """Restituisce statistiche sul dataset caricato.

    Returns:
        dict con: count (int), themes (list di str)
    """
    if not _dataset:
        return {"count": 0, "themes": []}

    # raccoglie tutti i tag unici come lista
    all_tags: list = []
    for poem in _dataset:
        tags_raw = poem.get("tags", "")
        for tag in tags_raw.split(","):
            tag = tag.strip().lower()
            if tag and tag not in all_tags:
                all_tags.append(tag)

    return {"count": len(_dataset), "themes": sorted(all_tags)}


# ---------------------------------------------------------------------------
# 2. Filtro per tema
# ---------------------------------------------------------------------------

def filter_by_theme(theme: str) -> list:
    """Restituisce la lista di poesie che contengono il tema nei tag o nel titolo.

    Args:
        theme: stringa di tema (es. "love", "nature")

    Returns:
        lista di dizionari poesia (sottoinsieme di _dataset)
    """
    if not theme or not _dataset:
        return list(_dataset)  # copia della lista originale

    theme_lower = theme.lower().strip()
    filtered: list = []
    for poem in _dataset:
        tags_lower = poem.get("tags", "").lower()
        title_lower = poem.get("title", "").lower()
        poem_lower = poem.get("poem", "").lower()
        if theme_lower in tags_lower or theme_lower in title_lower or theme_lower in poem_lower:
            filtered.append(poem)

    # se il tema non trova nulla, usa tutto il dataset
    return filtered if filtered else list(_dataset)


# ---------------------------------------------------------------------------
# 3. Campionamento few-shot
# ---------------------------------------------------------------------------

def sample_poems(poems: list, n: int = 3) -> tuple:
    """Seleziona `n` poesie casuali dalla lista fornita.

    Restituiamo una tupla (immutabile) di dizionari: ogni dizionario è
    {"title", "author", "poem"} — una snapshot sicura per costruire il prompt.

    Args:
        poems: lista di dizionari poesia
        n:     numero di campioni da estrarre

    Returns:
        tupla di n dizionari (o meno se poems è corta)
    """
    n = min(n, len(poems))
    if n == 0:
        return ()
    sampled = random.sample(poems, n)
    # convertiamo in tuple di dict con solo i campi utili al prompt
    result: list = []
    for p in sampled:
        result.append({
            "title":  p.get("title", ""),
            "author": p.get("author", ""),
            "poem":   p.get("poem", "")[:600],  # tronca a 600 char per non saturare il contesto
        })
    return tuple(result)


# ---------------------------------------------------------------------------
# 4. Costruzione del prompt
# ---------------------------------------------------------------------------

def build_prompt(samples: tuple, theme: str, style: str, length: str) -> str:
    """Costruisce il prompt testuale per l'LLM.

    Struttura del prompt (few-shot):
      - Istruzione di sistema (ruolo)
      - Esempi di poesie reali dal dataset
      - Richiesta finale con tema, stile e lunghezza desiderata

    Args:
        samples: tupla di dict {"title", "author", "poem"}
        theme:   tema richiesto (es. "amore", "morte", "natura")
        style:   stile (es. "sonetto", "verso libero", "haiku")
        length:  lunghezza approssimativa ("short", "medium", "long")

    Returns:
        stringa prompt completa
    """
    # mappa lunghezza → descrizione
    length_map: dict = {
        "short":  "breve (4-8 versi)",
        "medium": "media lunghezza (10-16 versi)",
        "long":   "lunga (20+ versi)",
    }
    length_desc: str = length_map.get(length, "media lunghezza (10-16 versi)")

    # intestazione del prompt
    prompt_parts: list = [
        "Sei un poeta di alto livello. Il tuo compito è scrivere una poesia originale.",
        "Ecco alcune poesie di riferimento tratte da una raccolta reale:\n",
    ]

    # inserisci gli esempi few-shot
    for i, sample in enumerate(samples):
        example_block: str = (
            f"--- Esempio {i+1} ---\n"
            f"Titolo: {sample['title']}\n"
            f"Autore: {sample['author']}\n"
            f"Testo:\n{sample['poem']}\n"
        )
        prompt_parts.append(example_block)

    # richiesta finale
    request_block: str = (
        "\n--- La tua poesia ---\n"
        f"Scrivi una poesia originale ispirata agli esempi qui sopra.\n"
        f"Tema: {theme if theme else 'libero'}\n"
        f"Stile: {style if style else 'verso libero'}\n"
        f"Lunghezza: {length_desc}\n"
        "Scrivi SOLO la poesia, senza spiegazioni, senza titolo prefissato, "
        "senza frasi introduttive. Inizia direttamente con il primo verso."
    )
    prompt_parts.append(request_block)

    # unisci tutto in una singola stringa
    return "\n".join(prompt_parts)


# ---------------------------------------------------------------------------
# 5. Chiamata all'LLM
# ---------------------------------------------------------------------------

def call_llm(prompt: str, api_key: str, model: str = "claude-sonnet-4-20250514") -> dict:
    """Chiama l'API Anthropic e restituisce la poesia generata.

    Usa solo urllib (standard library) per non aggiungere dipendenze.

    Args:
        prompt:  stringa prompt costruita da build_prompt()
        api_key: chiave API Anthropic (stringa)
        model:   identificatore del modello (default: claude-sonnet-4-20250514)

    Returns:
        dict con chiavi: ok (bool), poem (str), error (str|None)
    """
    endpoint: str = "https://api.anthropic.com/v1/messages"

    # corpo della richiesta come dizionario → poi serializzato in JSON
    body: dict = {
        "model":      model,
        "max_tokens": 1024,
        "messages": [
            {"role": "user", "content": prompt}
        ],
    }

    body_bytes: bytes = json.dumps(body).encode("utf-8")

    headers: dict = {
        "Content-Type":      "application/json",
        "x-api-key":         api_key,
        "anthropic-version": "2023-06-01",
    }

    try:
        req = urllib.request.Request(endpoint, data=body_bytes, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
        response_data: dict = json.loads(raw)
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8")
        return {"ok": False, "poem": "", "error": f"HTTP {e.code}: {error_body}"}
    except Exception as e:
        return {"ok": False, "poem": "", "error": str(e)}

    # estrai il testo dalla risposta
    content_blocks: list = response_data.get("content", [])
    poem_text: str = ""
    for block in content_blocks:
        if block.get("type") == "text":
            poem_text += block.get("text", "")

    if not poem_text:
        return {"ok": False, "poem": "", "error": "Risposta vuota dall'LLM"}

    return {"ok": True, "poem": poem_text.strip(), "error": None}


# ---------------------------------------------------------------------------
# 6. Pipeline completa (funzione di convenienza)
# ---------------------------------------------------------------------------

def generate_poem(theme: str, style: str, length: str, api_key: str) -> dict:
    """Pipeline completa: filtra → campiona → costruisce prompt → chiama LLM.

    Args:
        theme:   tema (stringa, può essere vuota)
        style:   stile poetico (stringa)
        length:  "short" | "medium" | "long"
        api_key: chiave API Anthropic

    Returns:
        dict con: ok (bool), poem (str), samples_used (int), error (str|None)
    """
    if not is_loaded():
        return {"ok": False, "poem": "", "samples_used": 0, "error": "Dataset non caricato. Chiama /train prima."}

    # 1. Filtra per tema
    filtered: list = filter_by_theme(theme)

    # 2. Campiona few-shot examples (tupla)
    samples: tuple = sample_poems(filtered, n=3)

    # 3. Costruisce il prompt (stringa)
    prompt: str = build_prompt(samples, theme, style, length)

    # 4. Chiama l'LLM
    result: dict = call_llm(prompt, api_key)

    result["samples_used"] = len(samples)
    return result
